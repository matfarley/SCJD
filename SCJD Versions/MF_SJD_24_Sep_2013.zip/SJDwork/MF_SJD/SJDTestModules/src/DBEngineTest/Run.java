/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DBEngineTest;

/**
 *
 * @author matthewfarley
 */
public class Run {
    public static void main(String[] args){
        DBEngineTest db = new DBEngineTest ("H:\\SJDwork\\MF_SJD\\db-2x2_WORKING.db");
        String record = new String(db.readRecord(0));
        System.out.println(record);
    }
}
