/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DBEngineTest;

import java.io.*;
import java.util.*;




/**
 *  This class does all the work of the database, instantiating the files,
 *  reading, writing and searching.
 * 
 * @author matthewfarley
 */
public class DBEngineTest {
    private String path;
    private StringBuilder blankRecord = 
            new StringBuilder(Contractor.RECORD_LENGTH);
    private File file;
    private RandomAccessFile dbFile;
    //Map used to store a record of the starting point of each record.
    private Map<String, Long> recordNumbers;
    
    
    /** Creates new DBEngine 
     *  
     * @param path      The location of the database file
     */
    public DBEngineTest(String path){
        this.path = path;
        try{
            file = new File(path);
            dbFile = new RandomAccessFile(file, "rw");
            
        }catch(IOException ioe){
            System.out.println("IOException\n" + ioe);
        }//figure out how to handle exceptions later.  Throw Database Exception?
    }
    
    //public xxx getRecords(){}
    //public xxx buildRecordNumbers();
    
    //trying to get a single record out of the DB.
    public byte[] readRecord(int location){
        int offset;
        //use if statement to check if records are null.  If so then use
        offset = Contractor.OFFSET_LENGTH;
        // if records are not null then get the offset(location in record)
        // from the map
        
        byte[] temp = new byte[Contractor.RECORD_LENGTH];
        try{
            dbFile.seek(offset);
            dbFile.readFully(temp);

        }catch(IOException ioe){
            System.out.println("Exception while reading records\n" +
                    " from database file\n" + ioe);
        }
        
        //calls addToRecordNumbers() when creating
        
        return temp;
    }

}
