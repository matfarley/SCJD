/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

/**
 *
 * @author 90045985
 */
public enum Mode {
    SERVER, ALONE
}
