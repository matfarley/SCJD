/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package db;

/**
 * Enum is used as a flag for the search functionality of the database
 *@author  Matthew Farley  90045985
 *09 October 2013	
 *@version 1.0
 */
public enum SearchMode {
    NAME, LOCATION, NAME_AND_LOCATION
}
