/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

/**
 *  Enumerator flag used to pass information regarding the mode of operation 
 *  down the call stack.
 * 
 * @author 90045985
 */
public enum Mode {
    DIRECT, NETWORKED
}
