/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package gui;

/**
 *  Enumerator flag used to pass information regarding the mode of operation 
 *  down the call stack.
 * 
 *@author  Matthew Farley  90045985
 *09 October 2013	
 *@version 1.0
 */
public enum Mode {
    DIRECT, NETWORKED
}
