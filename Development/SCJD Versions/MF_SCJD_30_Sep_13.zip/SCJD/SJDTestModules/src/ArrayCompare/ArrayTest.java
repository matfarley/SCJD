/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ArrayCompare;

/**
 *
 * @author matthewfarley
 */
public class ArrayTest {
    public static void main(String[] args){
        String[] test1 = new String[]{"Matt", "Auckland"};
        if()
    }
}
