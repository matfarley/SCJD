/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package db;

/**
 * Enum is used as a flag for the search functionality of the database
 * @author 90045985
 */
public enum SearchMode {
    NAME, LOCATION, NAME_AND_LOCATION
}
