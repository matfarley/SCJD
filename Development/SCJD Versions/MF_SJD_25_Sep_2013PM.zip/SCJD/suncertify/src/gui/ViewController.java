/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package gui;

/**
 * This class works as an intermediary between the view and the data portions 
 * of the program, packaging search results sets into TableModels so that they
 * can be displayed and taking search terms and packaging them into regex 
 * statements
 * 
 * @author matthewfarley
 */
public class ViewController {
    
}
