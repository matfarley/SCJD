/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DBEngineTest;

import java.io.*;
import java.util.*;



/**
 *  This class does all the work of the database, instantiating the files,
 *  reading, writing and searching.
 * 
 * @author matthewfarley
 */
public class DBEngineTest {
    private String path;
    private File file = null;
    
    private RandomAccessFile dbFile = null;
    private StringBuilder blankRecord;
    private Map recordsMap;
    private long length;
     byte[] testRead;
     int offset = 69;
    
    
    /** Creates new DBEngineTest */
    public DBEngineTest(String path){
        super();
        this.path = path;
        try{
            
            file = new File(path);
            
            
            
            dbFile = new RandomAccessFile(file, "rw");
            
            length = dbFile.length();
           
            
        }catch(IOException ioe){
            System.out.println("Exception at line 30"+ ioe);
        } //figure out what to do with exceptions later
        
    }
    
    public void readFile(){
        try{
            System.out.println("Offset length: " + offset);
            System.out.println("Single record");
            byte[] record = new byte[184];
            
            dbFile.seek(offset);
            dbFile.readFully(record);
            String recordString = new String(record);
            System.out.println(recordString);
            dbFile.seek(offset + record.length);
            dbFile.readFully(record);
            recordString = new String(record);
            System.out.println(recordString);
            dbFile.seek(offset + record.length + record.length);
            dbFile.readFully(record);
            recordString = new String(record);
            System.out.println(recordString);
            dbFile.seek(offset + record.length + record.length + record.length);
            dbFile.readFully(record);
            recordString = new String(record);
            System.out.println(recordString);
             dbFile.seek(offset + record.length + record.length + record.length + record.length);
            dbFile.readFully(record);
            recordString = new String(record);
            System.out.println(recordString);
              dbFile.seek(offset + record.length + record.length + record.length + record.length + record.length);
            dbFile.readFully(record);
            recordString = new String(record);
            System.out.println(recordString);
            
            System.out.println("Full dB");
            dbFile.seek(0);
            testRead = new byte[(int)dbFile.length()];
            
            dbFile.readFully(testRead, 0, testRead.length);
            String recordTest2 = new String(testRead);
            System.out.println("record = " + recordTest2);
            

            
            
           
        }catch(IOException ioe){
              System.out.println("Exception at line 39"+ ioe);
        }
        
    }
    
}
