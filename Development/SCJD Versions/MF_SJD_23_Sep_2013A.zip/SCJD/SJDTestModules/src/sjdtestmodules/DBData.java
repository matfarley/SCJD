/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sjdtestmodules;

/**
 *
 * @author matthewfarley
 */
public class DBData {
   private String data = "Test Data";
   
   String getData(){
       return data;
   }
}
