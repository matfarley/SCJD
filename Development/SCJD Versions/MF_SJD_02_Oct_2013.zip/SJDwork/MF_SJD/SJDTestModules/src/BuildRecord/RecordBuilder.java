/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package BuildRecord;

import DBEngineTest.Contractor;

/**
 *
 * @author 90045985
 */
public class RecordBuilder {
 
    //include this step so that the new string is padded with blanks.
public String protoRecordString = new String(new byte[(Contractor.RECORD_LENGTH - Contractor.FLAG_LENGTH)]);
    public StringBuilder blankRecord = 
            new StringBuilder(protoRecordString);
    


    
     public String buildRecord(String name, String city, String specialties, 
            String staffNo, String rate){
             System.out.println("protoString length" + protoRecordString.length() + "blank record capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
         
        int offset = 0;
        System.out.println("OFFSET " + offset + "capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
        
        //blankRecord.insert(offset, name);
        blankRecord.replace(offset, (offset + Contractor.NAME_LENGTH), name); //update string operations to look like this
        System.out.println("OFFSET " + offset + "capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
        offset+= Contractor.NAME_LENGTH;
        
        //blankRecord.insert(offset, city);
        blankRecord.replace(offset, Contractor.CITY_LENGTH, city);
        System.out.println("OFFSET " + offset + "capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
        offset += Contractor.CITY_LENGTH;
        
        //blankRecord.insert(offset, specialties);
        blankRecord.replace(offset, Contractor.SPECIALTIES_LENGTH, specialties);
        System.out.println("OFFSET " + offset + "capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
        offset += Contractor.SPECIALTIES_LENGTH;
        
        //blankRecord.insert(offset, staffNo);
        blankRecord.replace(offset, Contractor.STAFF_LENGTH, staffNo);
        System.out.println("OFFSET " + offset + "capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
        offset += Contractor.STAFF_LENGTH;
        
        //blankRecord.insert(offset, rate);
        blankRecord.replace(offset, Contractor.RATE_LENGTH, rate);
        System.out.println("OFFSET " + offset + "capacity" + blankRecord.capacity() + " Length "
                + blankRecord.length());
        //No need to increment the offset as this is the last field.
        
        //Booking customer is not written to the file, because this is assigned
        //after the existingRecord exists in the database
                 

                 
        
        return blankRecord.toString();
    }

}
