/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package db;

import java.io.*;


/**
 *  This class does all the work of the database, instantiating the files,
 *  reading, writing and searching.
 * 
 * @author matthewfarley
 */
public class DBEngine {
    private String path;
    private File file;
    
    
    /** Creates new DBEngine */
    public DBEngine(String path){
        this.path = path;
    }
}
