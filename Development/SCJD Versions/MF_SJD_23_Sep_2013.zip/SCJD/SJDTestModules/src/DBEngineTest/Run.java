/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package DBEngineTest;

/**
 *
 * @author matthewfarley
 */
public class Run {
    public static void main(String[] args){
        DBEngineTest db = new DBEngineTest ("db-2x2_WORKING.db");
        db.readFile();
    }
}
