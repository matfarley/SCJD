/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package sjdtestmodules;

/**
 *
 * @author matthewfarley
 */
public class LockMgr {
    public void lock(){
        
    }
    
    public void unlock(){
    
    }    
}
