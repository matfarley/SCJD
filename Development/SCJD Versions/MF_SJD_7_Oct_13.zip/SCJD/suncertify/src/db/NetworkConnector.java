/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package db;

import server.*;
import java.rmi.*;
import java.rmi.registry.*;
import java.util.Arrays;
import java.net.*;

/**
 * Concrete implementation of the <code>Connector</code> interface, used to
 * connect to a remote database.  Acts as a client.
 * 
 * @author 90045985
 */
public class NetworkConnector implements Connector {
    private String path;
    private int port;
    private String dbName;
    private RemotableDB dbStub; //Use the Interface Type  RemotableDB
    private String fullName;
    
    /**
     * Creates a new <Code>LocalConnector</code> object
     * 
     * @param path
     * @param port
     * @throws RemoteException
     */
    public NetworkConnector(String path, int port) throws RemoteException,
            NotBoundException{  
        this.path = path;
        this.port = port;
        dbName = "remoteDB";
        fullName = "rmi://127.0.0.1/" + dbName; //testing this
        //Registry registry = LocateRegistry.getRegistry(port);
        try{
            Registry registry = LocateRegistry.getRegistry(null);
            System.out.println(Arrays.toString(registry.list()));// debugging
            dbStub = (RemotableDB)Naming.lookup(fullName); //- may need to create a longer url
            //dbStub = (RemotableDB)registry.lookup(dbName); // throws NotBound Exception
        }catch(Exception e){
            System.out.println(e);//used for debugging
        }
        

    }
    
    
    
    /**
     * 
     * @return      A server database object set with a path and port
     */
    @Override public RemotableDB getDatabase(){
        return this.dbStub;
    }
}
