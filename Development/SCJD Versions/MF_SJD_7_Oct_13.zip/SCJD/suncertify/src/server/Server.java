/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package server;

import db.Database;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.*;
import java.util.Arrays;

/**
 *
 * @author 90045985
 */
public class Server {
    private String path;
    private int port;
    private String dbName = "remoteDB"; //Name used with RMI registry
    private RemotableDB serverDB; //change to serverDatabase type
    //private RemotableDB dbStub; //database implementing the remote interface.
    private Registry registry;
    private String fullName;
    
    public Server(String path, int port) throws RemoteException{
        this. path = path;
        this.port = port;
        fullName = "rmi://localhost:"+ port + "/" + dbName; //testing this
        try{
            serverDB = new Database(path);
            registry = LocateRegistry.getRegistry();
            Naming.rebind(fullName, serverDB);
            System.out.println(Arrays.toString(registry.list()));// debugging
            System.out.println("serverDB bound"); // debugging
            
        }catch(Exception e){
            //System.out.println(e);
            e.printStackTrace();
        } //catching Malformed URL exception.  Figure this out!
        
    }
    
    public void close() throws NotBoundException, RemoteException{
        registry.unbind(dbName);
        UnicastRemoteObject.unexportObject(serverDB, true);
        System.out.println("serverDB unbound"); // debugging
    }

}
